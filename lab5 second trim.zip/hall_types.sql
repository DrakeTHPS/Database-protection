\connect sessions
insert into hall_types (id, hall_type, session_format, cost) values (1,'Стандарт','2D',300);
insert into hall_types (id, hall_type, session_format, cost) values (2,'Стандарт','2D SCREENX',400);
insert into hall_types (id, hall_type, session_format, cost) values (3,'Стандарт','3D',450);
insert into hall_types (id, hall_type, session_format, cost) values (4,'Стандарт','3D ATMOS',550);
insert into hall_types (id, hall_type, session_format, cost) values (5,'Премиум','2D',500);
insert into hall_types (id, hall_type, session_format, cost) values (6,'Премиум','3D',650);
insert into hall_types (id, hall_type, session_format, cost) values (7,'Комфорт','2D',400);
insert into hall_types (id, hall_type, session_format, cost) values (8,'Комфорт','3D',550);
insert into hall_types (id, hall_type, session_format, cost) values (9,'4DX','4DX 2D',600);
insert into hall_types (id, hall_type, session_format, cost) values (10,'4DX','4DX 3D',650);
insert into hall_types (id, hall_type, session_format, cost) values (11,'IMAX','IMAX 2D',500);
insert into hall_types (id, hall_type, session_format, cost) values (12,'IMAX','IMAX 3D',650);