CREATE DATABASE sessions;

\connect sessions

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

CREATE TABLE cinemas (
    id serial PRIMARY KEY,
    city VARCHAR(64) NOT NULL,
    address VARCHAR(64) NOT NULL
);

CREATE TABLE hall_types (
    id serial PRIMARY KEY,
    hall_type VARCHAR(64) NOT NULL,
    session_format VARCHAR(64) NOT NULL,
    cost INTEGER NOT NULL
);

CREATE TABLE halls (
    id serial PRIMARY KEY,
    cinema_id INTEGER NOT NULL,
    hall_type_id INTEGER NOT NULL,
    hall_no INTEGER NOT NULL
);

CREATE TABLE seats (
    hall_id INTEGER NOT NULL,
    seat_no INTEGER NOT NULL,
    PRIMARY KEY (hall_id, seat_no)
);

CREATE TABLE movies (
    id serial PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    genre VARCHAR(64) NOT NULL,
    duration INTEGER NOT NULL,
    age_limit INTEGER NOT NULL    
);

CREATE TABLE sessions (
    id INTEGER NOT NULL PRIMARY KEY,
    hall_id INTEGER NOT NULL,
    datetime TIMESTAMP,
    movie_id INTEGER NOT NULL,
    available_for_purchase SMALLINT
);

CREATE TABLE tickets (
    session_id INTEGER NOT NULL,
    seat_no INTEGER NOT NULL,
    PRIMARY KEY (session_id, seat_no)
);

CREATE TABLE booking (
    session_id INTEGER NOT NULL,
    seat_no INTEGER NOT NULL,
    expiration_date TIMESTAMP,
    PRIMARY KEY (session_id, seat_no)
);