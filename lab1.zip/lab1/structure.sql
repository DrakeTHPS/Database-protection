CREATE DATABASE "D:\firebirdDB\sessions.fdb";

CREATE TABLE cinemas (
    id INTEGER NOT NULL PRIMARY KEY,
    city VARCHAR(64) CHARACTER SET UNICODE_FSS NOT NULL,
    address VARCHAR(64) CHARACTER SET UNICODE_FSS NOT NULL
);

CREATE TABLE hall_types (
    id INTEGER NOT NULL PRIMARY KEY,
    hall_type VARCHAR(64) CHARACTER SET UNICODE_FSS NOT NULL,
    session_format VARCHAR(64) CHARACTER SET UNICODE_FSS NOT NULL,
    cost INTEGER NOT NULL
);

CREATE TABLE halls (
    id INTEGER NOT NULL PRIMARY KEY,
    cinema_id INTEGER NOT NULL,
    hall_type_id INTEGER NOT NULL,
    hall_no INTEGER NOT NULL
);

CREATE TABLE seats (
    hall_id INTEGER NOT NULL,
    seat_no INTEGER NOT NULL
);

ALTER TABLE seats
    ADD CONSTRAINT seats_pKEY PRIMARY KEY (hall_id, seat_no);

CREATE TABLE movies (
    id INTEGER NOT NULL PRIMARY KEY,
    name VARCHAR(64) CHARACTER SET UNICODE_FSS NOT NULL,
    genre VARCHAR(64) CHARACTER SET UNICODE_FSS NOT NULL,
    duration INTEGER NOT NULL,
    age_limit INTEGER NOT NULL    
);

CREATE TABLE sessions (
    id INTEGER NOT NULL PRIMARY KEY,
    hall_id INTEGER NOT NULL,
    datetime TIMESTAMP,
    movie_id INTEGER NOT NULL,
    available_for_purchase SMALLINT
);

CREATE TABLE tickets (
    session_id INTEGER NOT NULL,
    seat_no INTEGER NOT NULL
);
ALTER TABLE tickets
    ADD CONSTRAINT tickets_pKEY PRIMARY KEY (session_id, seat_no);

CREATE TABLE booking (
    session_id INTEGER NOT NULL,
    seat_no INTEGER NOT NULL,
    expiration_date TIMESTAMP
);

ALTER TABLE booking
    ADD CONSTRAINT booking_pKEY PRIMARY KEY (session_id, seat_no);